Download Links for [videojs](http://videojs.com):
  video.js: http://vjs.zencdn.net/5.10.2/video.js
  video-js.css: http://vjs.zencdn.net/5.10.2/video-js.css
  License: https://github.com/videojs/video.js/blob/master/LICENSE
