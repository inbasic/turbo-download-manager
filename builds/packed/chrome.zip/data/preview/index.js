/* globals background */
'use strict';
'use strict';

var url = /url\=([^\&]+)/.exec(document.location.search);
if (url && url.length) {
  url = decodeURIComponent(url[1]);
}
console.error(url);
