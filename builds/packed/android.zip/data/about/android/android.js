'use strict';

var listeners = [];

window.addEventListener('message', function (e) {
  if (e.source === e.target) {
    return;
  }
  listeners.forEach(function (c) {
    c(e.data, { url: 'background.html' });
  });
});

var background = { // jshint ignore:line
  send: function send(id, data) {
    return window.top.postMessage({
      method: id + '@ab',
      data: data
    }, '*');
  },
  receive: function receive(id, callback) {
    return listeners.push(function (request, sender) {
      if (request.method === id + '@ab' && (!sender.url || sender.url.indexOf('background') !== -1)) {
        callback(request.data);
      }
    });
  }
};