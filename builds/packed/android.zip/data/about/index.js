/* globals background */
'use strict';

/* generating links */

function updates(url) {
  var req = new XMLHttpRequest();
  req.open('GET', url, true);
  req.responseType = 'json';
  req.onload = function () {
    try {
      var latest = req.response[0];
      latest.assets.forEach(function (obj) {
        var elem = document.querySelector('[data-prerelease="' + obj.name + '"]');
        if (elem) {
          elem.setAttribute('href', obj.browser_download_url);
          elem.textContent = 'Link';
        }
      });
      latest = req.response.filter(function (obj) {
        return obj.prerelease === false;
      });
      if (latest && latest.length) {
        latest = latest[0];
        latest.assets.forEach(function (obj) {
          var elem = document.querySelector('[data-release="' + obj.name + '"]');
          if (elem) {
            elem.setAttribute('href', obj.browser_download_url);
            elem.textContent = 'Link';
          }
        });
      }
    } catch (e) {}
  };
  req.send();
}

background.receive('init', function (obj) {
  document.querySelector('[data-id=version]').textContent = obj.version;
  document.querySelector('[data-id=platform]').textContent = obj.platform;
  updates(obj.url);
});
background.send('init');

document.addEventListener('click', function (e) {
  var url = e.target.href;
  if (url) {
    e.preventDefault();
    background.send('open', url);
  }
});