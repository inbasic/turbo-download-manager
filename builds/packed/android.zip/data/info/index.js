/* globals background */
'use strict';

var id = /id\=([^\&]+)/.exec(document.location.search);
id = id && id.length ? +id[1] : null;

background.receive('log', function (obj) {
  if (obj.id === id) {
    (function () {
      var parent = document.querySelector('#log tbody');

      obj.log.forEach(function (obj) {
        var tr = document.createElement('tr');
        var date = document.createElement('td');
        date.textContent = obj.date;
        tr.appendChild(date);
        var msgParent = document.createElement('td');
        var msg = document.createElement('pre');

        if (obj.link) {
          var tmp = obj.log.split(obj.link);
          msg.appendChild(document.createTextNode(tmp[0]));
          var a = document.createElement('a');
          a.textContent = a.href = obj.link;
          a.target = '_blank';
          msg.appendChild(a);
          msg.appendChild(document.createTextNode(tmp[1]));
        } else {
          msg.textContent = obj.log;
        }

        msgParent.appendChild(msg);
        tr.appendChild(msgParent);
        parent.appendChild(tr);
      });
    })();
  }
});

background.receive('status', function (obj) {
  if (obj.id === id) {
    document.body.dataset.status = obj.status;
  }
});

document.addEventListener('click', function (e) {
  var target = e.target;
  var cmd = target.dataset.cmd;

  if (cmd) {
    if (cmd === 'remove') {
      var rtn = window.confirm('File will be removed permanently. Proceed?');
      if (!rtn) {
        return;
      }
    }
    background.send('cmd', {
      cmd: cmd,
      id: id
    });
  }
});

if (id !== null) {
  background.send('init', id);
}