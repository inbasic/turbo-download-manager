/* globals background, showdown */
'use strict';

var id = /id\=([^\&]+)/.exec(document.location.search);
id = id && id.length ? +id[1] : null;

background.receive('log', function (obj) {
  if (obj.id === id) {
    (function () {
      var converter = new showdown.Converter({
        simplifiedAutoLink: true
      });

      var parent = document.querySelector('#log tbody');

      obj.log.forEach(function (obj) {
        var tr = document.createElement('tr');
        var date = document.createElement('td');
        date.textContent = obj.date;
        tr.appendChild(date);
        var msgParent = document.createElement('td');
        var msg = document.createElement('pre');
        // this is a safe HTML
        msg.innerHTML = converter.makeHtml(obj.log);
        if (obj.properties) {
          if (obj.properties.type) {
            tr.dataset.type = obj.properties.type;
          }
        }

        msgParent.appendChild(msg);
        tr.appendChild(msgParent);
        parent.appendChild(tr);
      });
    })();
  }
});

background.receive('status', function (obj) {
  if (obj.id === id) {
    document.body.dataset.status = obj.status;
  }
});

document.addEventListener('click', function (e) {
  var target = e.target;
  var cmd = target.dataset.cmd;

  if (cmd) {
    if (cmd === 'remove') {
      var rtn = window.confirm('File will be removed permanently. Proceed?');
      if (!rtn) {
        return;
      }
    }
    background.send('cmd', {
      cmd: cmd,
      id: id
    });
  }

  var href = target.href;
  if (href && e.which === 1) {
    // left click only
    e.preventDefault();
    e.stopPropagation();
    background.send('open', href);
  }
});

if (id !== null) {
  background.send('init', id);
}