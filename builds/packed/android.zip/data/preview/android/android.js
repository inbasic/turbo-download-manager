'use strict';

var background = { // jshint ignore:line
  send: function send(id, data) {
    return window.top.listeners.background.forEach(function (c) {
      c({ method: id + '@pr', data: data }, { url: 'preview.html' });
    });
  },
  receive: function receive(id, callback) {
    return window.top.listeners.pagemod.push(function (request, sender) {
      if (request.method === id + '@pr' && sender.url.indexOf('background') !== -1) {
        callback(request.data);
      }
    });
  }
};