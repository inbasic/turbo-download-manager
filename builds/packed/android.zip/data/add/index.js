/* globals background, manifest */
'use strict';

document.querySelector('form').addEventListener('submit', function (e) {
  var folder = document.querySelector('[data-id=folder]').value;
  if (!folder && manifest.folder) {
    return background.send('no-folder');
  }
  background.send('download', {
    url: document.querySelector('[data-id=url]').value,
    alternatives: [].map.call(document.querySelectorAll('[data-id=alternative'), function (e) {
      return e.value;
    }),
    name: document.querySelector('[data-id=name]').value,
    description: document.querySelector('[data-id=description]').value,
    timeout: +document.querySelector('[data-id=timeout]').value,
    threads: +document.querySelector('[data-id=threads]').value,
    folder: document.querySelector('[data-id=folder]').value,
    'auto-pause': document.querySelector('[data-id="auto-pause"]').checked
  });
  e.preventDefault();
  e.stopPropagation();
  return true;
});

background.receive('folder', function (folder) {
  document.querySelector('[data-id=folder]').value = folder;
});

document.addEventListener('click', function (e) {
  var target = e.target;
  var cmd = target.dataset.cmd;
  if (cmd) {
    background.send('cmd', { cmd: cmd });
    if (cmd === 'empty') {
      document.querySelector('[data-id=folder]').value = '';
    }
    if (cmd === 'plus') {
      var parent = document.querySelector('#t2 tbody');
      var tr = parent.querySelector('tr:nth-child(2)').cloneNode(true);
      parent.appendChild(tr);
      tr.querySelector('input').focus();
    }
    if (cmd === 'minus') {
      var tr = target.parentNode.parentNode;
      tr.parentNode.removeChild(tr);
    }
  }
});

background.receive('init', function (obj) {
  for (var name in obj.settings) {
    var elem = document.querySelector('[data-id="' + name + '"]');
    if (elem && obj.settings[name]) {
      elem.value = obj.settings[name];
    }
  }
  document.querySelector('[data-id=url]').value = obj.clipboard;
});
background.send('init');
// autofocus is not working on Firefox
window.setTimeout(function () {
  return document.querySelector('[data-id=url]').focus();
}, 500);
//
document.body.dataset.support = manifest.support;