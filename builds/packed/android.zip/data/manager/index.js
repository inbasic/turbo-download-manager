/* globals background, manifest */
'use strict';

function bytesToSize(bytes) {
  if (bytes === 0) {
    return '0 Byte';
  }
  var k = 1024;
  var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  var i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(i ? 1 : 0) + ' ' + sizes[i];
}
function intervalToTime(sec) {
  if (isNaN(sec) || !isFinite(sec)) {
    return '--:--:--:--';
  }
  var x = sec;
  var seconds = ('00' + parseInt(x % 60)).substr(-2);
  x /= 60;
  var minutes = ('00' + parseInt(x % 60)).substr(-2);
  x /= 60;
  var hours = ('00' + parseInt(x % 24)).substr(-2);
  x /= 24;
  var days = ('00' + parseInt(x)).substr(-2);

  return [days, hours, minutes, seconds].join(':');
}

var confirm = function (parent, ok, cancel, span) {
  var callback = function callback() {};
  ok.addEventListener('click', function () {
    parent.dataset.visible = false;
    callback();
  });
  cancel.addEventListener('click', function () {
    parent.dataset.visible = false;
  });
  return function (msg, c) {
    span.textContent = msg;
    parent.dataset.visible = true;
    callback = c;
  };
}(document.getElementById('confirm'), document.querySelector('#confirm input'), document.querySelector('#confirm input:last-child'), document.querySelector('#confirm span'));

// menu
(function (button, menu) {
  // clear
  function clear(list) {
    list.forEach(function (item) {
      item.querySelector('[data-cmd=trash]').click();
    });
  }
  button.addEventListener('click', function () {
    button.dataset.toggle = button.dataset.toggle === 'open' ? 'close' : 'open';
  });
  menu.addEventListener('click', function (e) {
    var target = e.target;
    var role = target.dataset.role;
    if (role === 'done' || role === 'error') {
      var items = document.querySelectorAll('.item');
      clear([].filter.call(items, function (i) {
        return i.dataset.type === role;
      }));
    } else {
      background.send('open', role);
    }
  });
  document.addEventListener('click', function (e) {
    if (!button.contains(e.target)) {
      button.dataset.toggle = 'close';
    }
  });
})(document.querySelector('#menu div[data-role=button]'), document.querySelector('#menu ul'));

// toolbar
var toolbar = function (search) {
  // filter
  function filter(e) {
    var items = document.querySelectorAll('.item');
    if (e.target.value) {
      [].forEach.call(items, function (item) {
        var name = get(item.dataset.id).name;
        item.dataset.filtered = name && name.indexOf(e.target.value) !== -1 ? false : true;
      });
    } else {
      [].forEach.call(items, function (i) {
        return i.dataset.filtered = false;
      });
    }
  }
  search.addEventListener('input', filter);
  return {
    set search(value) {
      search.value = value;
      search.dispatchEvent(new Event('input'));
    }
  };
}(document.querySelector('#toolbar input[type=search]'));

// items
var get = function get(id) {
  var parent = document.querySelector('.item[data-id="' + id + '"]');
  if (!parent) {
    return null;
  }
  var overal = parent.querySelector('[data-type=overal]>div');
  var percent = parent.querySelector('[data-type=percent]');
  var size = parent.querySelector('[data-type=size]');
  var speed = parent.querySelector('[data-type=speed]');
  var time = parent.querySelector('[data-type=time]');
  var name = parent.querySelector('[data-type=name]');
  var threads = parent.querySelector('[data-type=threads]');
  var retries = parent.querySelector('[data-type=retries]');

  return {
    set percent(p) {
      // jshint ignore: line
      overal.style.width = p + '%';
      percent.textContent = p.toFixed(1) + '%';
    },
    set size(s) {
      // jshint ignore: line
      size.textContent = bytesToSize(s);
    },
    get name() {
      return name.textContent;
    },
    set name(n) {
      name.textContent = n || name.textContent;
    },
    set threads(n) {
      // jshint ignore: line
      threads.textContent = n;
    },
    set retries(n) {
      // jshint ignore: line
      retries.textContent = n;
    },
    set speed(s) {
      // jshint ignore: line
      speed.textContent = bytesToSize(s) + '/s';
    },
    set time(s) {
      // jshint ignore: line
      time.textContent = s;
    },
    partial: function partial(id, offset, percent, color) {
      var holder = parent.querySelector('[data-type=partial]');
      var item = holder.querySelector('div[data-id="' + id + '"]');
      if (!item) {
        item = document.createElement('div');
        holder.appendChild(item);
        item.dataset.id = id;
      }
      item.style.left = offset + '%';
      item.style.width = percent + '%';
      item.style.backgroundColor = color;
    },
    clear: function clear() {
      var holder = parent.querySelector('[data-type=partial]');
      holder.innerHTML = '';
    },
    set status(val) {
      // jshint ignore: line
      parent.dataset.type = val;
    },
    get chunkable() {
      return parent.dataset.chunkable;
    },
    set chunkable(val) {
      parent.dataset.chunkable = val;
    }
  };
};
// add && info
(function (add, loader, iframe) {
  (function (blank) {
    loader.addEventListener('click', function (e) {
      return iframe.contains(e.target) ? '' : blank();
    });
    background.receive('hide', blank, false);
    document.addEventListener('backbutton', function (e) {
      e.preventDefault();
      blank();
    }, false);
  })(function () {
    if (loader.dataset.visible === 'true') {
      loader.dataset.visible = false;
      iframe.src = 'about:blank';
    }
  });
  add.addEventListener('click', function () {
    loader.dataset.visible = true;
    iframe.src = '../add/index.html';
  }, false);
  background.receive('info', function (id) {
    loader.dataset.visible = true;
    iframe.src = '../info/index.html?id=' + id;
  });
  background.receive('modify', function (id) {
    loader.dataset.visible = true;
    iframe.src = '../modify/index.html?id=' + id;
  });
  background.receive('triggers', function () {
    loader.dataset.visible = true;
    iframe.src = '../triggers/index.html';
  });
  background.receive('about', function () {
    loader.dataset.visible = true;
    iframe.src = '../about/index.html';
  });
})(document.getElementById('add'), document.getElementById('loader'), document.querySelector('#loader iframe'));

// items
function add(id) {
  toolbar.search = '';
  var parent = document.querySelector('.item[data-id="-1"]').cloneNode(true);
  var refrence = document.querySelector('.item');
  parent.dataset.id = id;
  document.body.insertBefore(parent, refrence);
  return get(id);
}
function remove(id) {
  var parent = document.querySelector('.item[data-id="' + id + '"]');
  if (parent) {
    parent.parentNode.removeChild(parent);
  }
}
background.receive('remove', remove);
background.receive('add', function (obj) {
  var item = add(obj.id);
  item.percent = obj.percent || 0;
  item.size = obj.size;
  item.threads = obj.threads;
  item.name = obj.name;
  item.status = obj.status;
  item.speed = obj.speed;
  item.retries = obj.retries;
  item.chunkable = obj.chunkable;
  for (var id in obj.stats) {
    var stat = obj.stats[id];
    item.partial(id, stat.start * 100, stat.width * 100, id);
  }
});
background.receive('new', function (id) {
  add(id);
});
background.receive('percent', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.percent = obj.percent;
  }
});
background.receive('speed', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.speed = obj.speed;
    item.time = intervalToTime(obj.time);
  }
});
background.receive('name', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.name = obj.name;
  }
});
background.receive('size', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.size = obj.size;
  }
});
background.receive('chunkable', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.chunkable = obj.chunkable;
  }
});
background.receive('status', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.status = obj.status;
    if (obj.status === 'done' || obj.status === 'error') {
      item.clear();
    }
  }
});
background.receive('count', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.threads = obj.count;
  }
});
background.receive('retries', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.retries = obj.retries;
  }
});
background.receive('progress', function (obj) {
  var item = get(obj.id);
  if (item) {
    var stat = obj.stat;
    item.partial(stat.id, stat.start * 100, stat.width * 100, stat.id);
  }
});
background.receive('browser', function (browser) {
  document.body.dataset.browser = browser;
});
background.send('init');

/* user interaction */
document.addEventListener('click', function (e) {
  var target = e.target;
  if (target.dataset.cmd) {
    [].filter.call(document.querySelectorAll('.item'), function (i) {
      return i.contains(target);
    }).forEach(function (i) {
      if (target.dataset.cmd === 'pause') {
        (function () {
          var cmd = i.dataset.type === 'download' ? 'pause' : 'resume';
          if (cmd === 'pause' && i.dataset.chunkable === 'false') {
            confirm('Download is not resumable. Pausing will result in termination. Proceed?', function () {
              return background.send('cmd', { id: i.dataset.id, cmd: cmd });
            });
          } else {
            background.send('cmd', { id: i.dataset.id, cmd: cmd });
          }
        })();
      } else if (target.dataset.cmd === 'trash') {
        background.send('cmd', { id: i.dataset.id, cmd: target.dataset.cmd });
        remove(i.dataset.id);
      } else {
        background.send('cmd', { id: i.dataset.id, cmd: target.dataset.cmd });
      }
    });
  }
});
// manifest
document.body.dataset.open = manifest.open;