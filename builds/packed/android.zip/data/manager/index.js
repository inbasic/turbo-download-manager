/* globals background, manifest */
'use strict';

function bytesToSize(bytes) {
  if (bytes === 0) {
    return '0 Byte';
  }
  var k = 1024;
  var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  var i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(i ? 1 : 0) + ' ' + sizes[i];
}
function intervalToTime(sec) {
  if (isNaN(sec) || !isFinite(sec)) {
    return '--:--:--:--';
  }
  var x = sec;
  var seconds = ('00' + parseInt(x % 60)).substr(-2);
  x /= 60;
  var minutes = ('00' + parseInt(x % 60)).substr(-2);
  x /= 60;
  var hours = ('00' + parseInt(x % 24)).substr(-2);
  x /= 24;
  var days = ('00' + parseInt(x)).substr(-2);

  return [days, hours, minutes, seconds].join(':');
}

var confirm = function (parent, ok, cancel, span) {
  var success = function success() {};
  ok.addEventListener('click', function () {
    parent.dataset.visible = false;
    success();
  });
  cancel.addEventListener('click', function () {
    parent.dataset.visible = false;
  });
  return function (msg, s) {
    span.textContent = msg;
    parent.dataset.visible = true;
    success = s || success;
  };
}(document.getElementById('confirm'), document.querySelector('#confirm input'), document.querySelector('#confirm input:last-child'), document.querySelector('#confirm span'));

var notify = function (parent, span, button) {
  button.addEventListener('click', function () {
    return parent.dataset.visible = false;
  });

  return function (msg) {
    span.textContent = msg;
    parent.dataset.visible = true;
  };
}(document.getElementById('notify'), document.querySelector('#notify span:nth-child(2)'), document.querySelector('#notify input'));
background.receive('notify', notify);

// menu
(function (button, menu) {
  // clear
  function clear(list) {
    list.forEach(function (item) {
      item.querySelector('[data-cmd=trash]').click();
    });
  }
  button.addEventListener('click', function () {
    button.dataset.toggle = button.dataset.toggle === 'open' ? 'close' : 'open';
  });
  document.addEventListener('menubutton', function () {
    return button.dataset.toggle = 'open';
  });
  menu.addEventListener('click', function (e) {
    var target = e.target;
    var role = target.dataset.role;
    if (role === 'done' || role === 'error') {
      var items = document.querySelectorAll('.item');
      clear([].filter.call(items, function (i) {
        return i.dataset.type === role;
      }));
    } else {
      background.send('open', role);
    }
  });
  document.addEventListener('click', function (e) {
    if (!button.contains(e.target)) {
      button.dataset.toggle = 'close';
    }
  });
})(document.querySelector('#menu div[data-role=button]'), document.querySelector('#menu ul'));

// toolbar
var toolbar = function (search) {
  // filter
  function filter(e) {
    var items = document.querySelectorAll('.item');
    if (e.target.value) {
      [].forEach.call(items, function (item) {
        var name = get(item.dataset.id).name;
        item.dataset.filtered = name && name.indexOf(e.target.value) !== -1 ? false : true;
      });
    } else {
      [].forEach.call(items, function (i) {
        return i.dataset.filtered = false;
      });
    }
  }
  search.addEventListener('input', filter);
  return {
    set search(value) {
      // jshint ignore:line
      search.value = value;
      try {
        search.dispatchEvent(new Event('input'));
      } catch (e) {}
    }
  };
}(document.querySelector('#toolbar input[type=search]'));

// items
var get = function get(id) {
  var parent = document.querySelector('.item[data-id="' + id + '"]');
  if (!parent) {
    return null;
  }
  var overal = parent.querySelector('[data-type=overal]>div');
  var percent = parent.querySelector('[data-type=percent]');
  var size = parent.querySelector('[data-type=size]');
  var speed = parent.querySelector('[data-type=speed]');
  var time = parent.querySelector('[data-type=time]');
  var name = parent.querySelector('[data-type=name]');
  var threads = parent.querySelector('[data-type=threads]');
  var retries = parent.querySelector('[data-type=retries]');

  return {
    set percent(p) {
      // jshint ignore: line
      p = Math.min(100, Math.abs(p) || 0);
      overal.style.width = p + '%';
      percent.textContent = p.toFixed(1) + '%';
    },
    set size(s) {
      // jshint ignore: line
      size.textContent = bytesToSize(s);
    },
    get name() {
      return name.textContent;
    },
    set name(n) {
      name.textContent = n || name.textContent;
    },
    set mime(n) {
      // jshint ignore: line
      parent.dataset.mime = n.split('/')[0];
    },
    set threads(n) {
      // jshint ignore: line
      threads.textContent = n;
    },
    set retries(n) {
      // jshint ignore: line
      retries.textContent = n;
    },
    set speed(s) {
      // jshint ignore: line
      speed.textContent = bytesToSize(s) + '/s';
    },
    set time(s) {
      // jshint ignore: line
      time.textContent = s;
    },
    partial: function partial(id, offset, percent, color) {
      var holder = parent.querySelector('[data-type=partial]');
      var item = holder.querySelector('div[data-id="' + id + '"]');
      if (!item) {
        item = document.createElement('div');
        holder.appendChild(item);
        item.dataset.id = id;
      }
      item.style.left = offset + '%';
      item.style.width = percent ? percent + '%' : '2px';
      item.style.backgroundColor = color;
    },
    clear: function clear() {
      var holder = parent.querySelector('[data-type=partial]');
      holder.innerHTML = '';
    },
    set status(val) {
      // jshint ignore: line
      parent.dataset.type = val;
    },
    get chunkable() {
      return parent.dataset.chunkable;
    },
    set chunkable(val) {
      parent.dataset.chunkable = val;
    }
  };
};
// add && info
var actions = function (add, loader, iframe) {
  (function (blank) {
    loader.addEventListener('click', function (e) {
      if (e.target === this) {
        blank();
      }
    });
    background.receive('hide', blank, false);
    window.top.document.addEventListener('backbutton', function (e) {
      e.preventDefault();
      blank();
    }, false);
    document.addEventListener('keyup', function (e) {
      if (e.keyCode === 27) {
        blank();
      }
    }, false);
  })(function () {
    if (loader.dataset.visible === 'true') {
      loader.dataset.visible = false;
      iframe.src = 'about:blank';
    }
  });
  function format(url) {
    return url.replace('http://', 'http---').replace('https://', 'https---').replace('resource://', 'resource---');
  }

  add.addEventListener('click', function () {
    return actions.add();
  }, false);
  background.receive('info', function (id) {
    loader.dataset.visible = true;
    iframe.src = '../info/index.html?id=' + id;
  });
  background.receive('modify', function (id) {
    loader.dataset.visible = true;
    iframe.src = '../modify/index.html?id=' + id;
  });
  background.receive('triggers', function () {
    loader.dataset.visible = true;
    iframe.src = '../triggers/index.html';
  });
  background.receive('about', function () {
    loader.dataset.visible = true;
    iframe.src = '../about/index.html';
  });
  background.receive('extract', function (url) {
    loader.dataset.visible = true;
    url = 'http://add0n.com/gmail-notifier.html?type=context';
    iframe.src = '../extract/index.html?url=' + encodeURIComponent(format(url));
  });
  background.receive('preview', function (obj) {
    loader.dataset.visible = true;
    iframe.src = '../preview/index.html?url=' + encodeURIComponent(format(obj.url)) + '&mime=' + obj.mime;
  });
  background.receive('config', function () {
    loader.dataset.visible = true;
    iframe.src = '../config/index.html';
  });
  background.receive('logs', function () {
    loader.dataset.visible = true;
    iframe.src = '../logs/index.html';
  });
  background.receive('job', function (url) {
    return actions.add(url);
  });

  return {
    add: function add(link) {
      loader.dataset.visible = true;
      iframe.src = '../add/index.html' + (link ? '?url=' + encodeURIComponent(format(link)) : '');
    }
  };
}(document.getElementById('add'), document.getElementById('loader'), document.querySelector('#loader iframe'));

// items
function add(id) {
  toolbar.search = '';
  var parent = document.querySelector('.item[data-id="-1"]').cloneNode(true);
  var refrence = document.querySelector('.item');
  parent.dataset.id = id;
  document.body.insertBefore(parent, refrence);
  return get(id);
}
function remove(id) {
  var parent = document.querySelector('.item[data-id="' + id + '"]');
  if (parent) {
    parent.parentNode.removeChild(parent);
  }
}
background.receive('remove', remove);
background.receive('add', function (obj) {
  var item = get(obj.id);
  if (!item) {
    item = add(obj.id);
    item.percent = obj.percent || 0;
    item.size = obj.size;
    item.threads = obj.threads;
    item.name = obj.name;
    item.mime = obj.mime;
    item.status = obj.status;
    item.speed = obj.speed;
    item.retries = obj.retries;
    item.chunkable = obj.chunkable;
    for (var id in obj.stats) {
      var stat = obj.stats[id];
      item.partial(id, stat.start * 100, stat.width * 100, id);
    }
  }
});
background.receive('new', function (id) {
  add(id);
});
background.receive('percent', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.percent = obj.percent;
  }
});
background.receive('speed', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.speed = obj.speed;
    item.time = intervalToTime(obj.time);
  }
});
background.receive('name', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.name = obj.name;
  }
});
background.receive('mime', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.mime = obj.mime;
  }
});
background.receive('size', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.size = obj.size;
  }
});
background.receive('chunkable', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.chunkable = obj.chunkable;
  }
});
background.receive('status', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.status = obj.status;
    if (obj.status === 'done' || obj.status === 'error') {
      item.clear();
    }
  }
});
background.receive('count', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.threads = obj.count;
  }
});
background.receive('retries', function (obj) {
  var item = get(obj.id);
  if (item) {
    item.retries = obj.retries;
  }
});
background.receive('progress', function (obj) {
  var item = get(obj.id);
  if (item) {
    var stat = obj.stat;
    item.partial(stat.id, stat.start * 100, stat.width * 100, stat.id);
  }
});
background.send('init');
background.receive('session:load', function () {
  return background.send('init');
});

/* user interaction */
document.addEventListener('click', function (e) {
  var target = e.target;
  if (target.dataset.cmd && e.which === 1) {
    [].filter.call(document.querySelectorAll('.item'), function (i) {
      return i.contains(target);
    }).forEach(function (i) {
      if (target.dataset.cmd === 'pause') {
        (function () {
          var cmd = i.dataset.type === 'download' ? 'pause' : 'resume';
          if (cmd === 'pause' && i.dataset.chunkable === 'false') {
            confirm('Download is not resumable. Pausing will result in termination. Proceed?', function () {
              return background.send('cmd', { id: i.dataset.id, cmd: cmd });
            });
          } else {
            background.send('cmd', { id: i.dataset.id, cmd: cmd });
          }
        })();
      } else if (target.dataset.cmd === 'trash') {
        background.send('cmd', { id: i.dataset.id, cmd: target.dataset.cmd });
        remove(i.dataset.id);
      } else {
        background.send('cmd', { id: i.dataset.id, cmd: target.dataset.cmd });
      }
    });
  }
  if (e.which === 2) {
    var cmd = target.dataset.cmd;
    if (cmd === 'open') {
      target.dataset.cmd = 'reveal';
    }
    if (cmd === 'reveal') {
      target.dataset.cmd = 'open';
    }
  }
});
/* drag & drop */
var dd = {
  drop: function drop(e) {
    e.preventDefault();
    // Get the id of the target and add the moved element to the target's DOM
    var link = e.dataTransfer.getData('text/uri-list');
    if (link) {
      actions.add(link);
    }
  },
  dragover: function dragover(e) {
    e.preventDefault();
    var types = Array.from(e.dataTransfer.types);
    e.dataTransfer.dropEffect = types.indexOf('text/uri-list') !== -1 ? 'link' : 'none';
  }
};
document.body.addEventListener('drop', dd.drop, false);
document.body.addEventListener('dragover', dd.dragover, false);
/* confirm */
background.receive('confirm', function (obj) {
  confirm(obj.msg, function () {
    return obj.cmd && background.send(obj.cmd);
  });
});
// manifest
document.body.dataset.developer = manifest.developer;
document.body.dataset.helper = manifest.helper;

// prevent redirection
(function (callback) {
  window.addEventListener('dragover', callback, false);
  window.addEventListener('drop', callback, false);
})(function (e) {
  if (e.target.tagName !== 'INPUT') {
    e.preventDefault();
  }
});