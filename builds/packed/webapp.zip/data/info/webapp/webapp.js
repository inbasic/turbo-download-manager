'use strict';

var background = {
  send: function send(id, msg) {
    id += '@if';
    window.top.postMessage({ id: id, msg: msg }, '*');
  },
  receive: function receive(id, callback) {
    id += '@if';
    window.addEventListener('message', function (e) {
      if (e.data && e.data.id === id) {
        callback(e.data.msg);
      }
    }, false);
  }
};
console.error(9);