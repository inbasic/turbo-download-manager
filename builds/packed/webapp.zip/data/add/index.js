/* globals background */
'use strict';
document.querySelector('#add input[type=button]').addEventListener('click', function () {
  background.send('download', {
    url: document.querySelector('[data-id=url]').value,
    description: document.querySelector('[data-id=description]').value,
    timeout: +document.querySelector('[data-id=timeout]').value,
    threads: +document.querySelector('[data-id=threads]').value,
    folder: document.querySelector('[data-id=folder]').value
  });
});

background.receive('folder', function (folder) {
  document.querySelector('[data-id=folder]').value = folder;
});

[].forEach.call(document.querySelectorAll('[data-cmd]'), function (elem) {
  elem.addEventListener('click', function () {
    background.send('cmd', {
      cmd: elem.dataset.cmd
    });
    if (elem.dataset.cmd === 'empty') {
      document.querySelector('[data-id=folder]').value = '';
    }
  });
});

background.receive('init', function (obj) {
  for (var _name in obj) {
    var elem = document.querySelector('[data-id="' + _name + '"]');
    if (elem && obj[_name]) {
      elem.value = obj[_name];
    }
  }
});
background.send('init');
// autofocus is not working on Firefox
window.setTimeout(function () {
  return document.querySelector('[data-id=url]').focus();
}, 500);