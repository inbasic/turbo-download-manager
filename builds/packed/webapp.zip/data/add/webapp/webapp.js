'use strict';

var background = {
  send: function send(id, msg) {
    id += '@ad';
    window.top.postMessage({ id: id, msg: msg }, '*');
  },
  receive: function receive(id, callback) {
    id += '@ad';
    window.addEventListener('message', function (e) {
      if (e.data && e.data.id === id) {
        callback(e.data.msg);
      }
    }, false);
  }
};